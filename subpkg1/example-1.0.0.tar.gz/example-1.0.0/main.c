#include <stdio.h>

int main()
{
    printf("%s", "I am doing nothing.\n");
    return 0;
}
